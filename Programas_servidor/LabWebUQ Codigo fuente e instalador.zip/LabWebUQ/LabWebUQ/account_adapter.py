from allauth.account.adapter import DefaultAccountAdapter


class AccountAdapter(DefaultAccountAdapter):
    '''
        Overrite django allauth default configuration
    '''
    pass
