google.charts.load('current', {'packages':['line']});
google.charts.setOnLoadCallback(drawChart);

document.addEventListener('DOMContentLoaded', () => {
    setInterval(count, 500);
    });

window.onload=function(){
    var A = document.getElementById("baudios");
    A.addEventListener("change", function(){
        b = document.getElementById("baudios");
        var req = new XMLHttpRequest();
        req.open('GET', '\\'+b.options[b.selectedIndex].value, true);
        req.send(null);
        document.querySelector('#Estado').innerHTML=b.options[b.selectedIndex].value;
    });
}


function count() {
    var req = new XMLHttpRequest();
    req.open('GET', url_estado, true);
    req.onreadystatechange = function (aEvt) {
        if (req.readyState === req.DONE) {
            document.querySelector('#Estado').innerHTML=req.responseText;
            };
    };
    req.send(null);
    var req2 = new XMLHttpRequest();
    var verifica_fechaHora = fechaHora;
    req2.open('GET', url_leer+fechaHora, true);
    req2.responseType = 'json'; 
    req2.onreadystatechange = function (aEvt) {
        if (req2.readyState === req2.DONE) {
            const jsonObj = req2.response;
            // Verificación para no duplicar datos
            if (verifica_fechaHora===fechaHora){
                document.querySelector('#Leido').innerHTML+=jsonObj['texto'];
                fechaHora = jsonObj['fechaHora'].slice(1,-1);
                if (document.querySelector('#IniFin').innerHTML=="Finalizar")
                drawChart();
        
            };
            };
    };
    req2.send(null);

    if(document.querySelector('#AutoScroll').checked) {
        var textarea = document.getElementById("Leido");
        textarea.scrollTop = textarea.scrollHeight;
        };
}

function Borrar() {
    document.querySelector('#Leido').innerHTML='';
    var req = new XMLHttpRequest();
    req.open('GET', url_limpiarSalida, true);
    req.send(null);
}

function download(data, filename, type) {
    var file = new Blob([data], {type: type});
    if (window.navigator.msSaveOrOpenBlob) // IE10+
        window.navigator.msSaveOrOpenBlob(file, filename);
    else { // Others
        var a = document.createElement("a"),
                url = URL.createObjectURL(file);
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        setTimeout(function() {
            document.body.removeChild(a);
            window.URL.revokeObjectURL(url);  
        }, 0); 
    }
}

function Grabar() {
/*    var req = new XMLHttpRequest();
    req.open('GET', url_grabarSalida, true);
    req.onreadystatechange = function (aEvt) {
        if (req.readyState === req.DONE) {                       
            download(req.responseText,"Datos.txt",{type: "text/plain;charset=utf-8"});
            };
    };
    req.send(null);*/

    download(document.querySelector('#Leido').innerHTML,"Datos.txt",{type: "text/plain;charset=utf-8"});
}
    
function IniFin() {
    var req = new XMLHttpRequest();
    if (document.querySelector('#IniFin').innerHTML=="Iniciar"){
        var idbaudios = document.getElementById("baudios");
        var enlace = idbaudios.options[idbaudios.selectedIndex].value;

        req.open('GET', enlace, true);
        document.querySelector('#IniFin').innerHTML="Finalizar";
        document.querySelector('#baudios').disabled=true;
    }else{
        req.open('GET', url_fin, true);
        document.querySelector('#IniFin').innerHTML="Iniciar";                   
        document.querySelector('#baudios').disabled=false;
    }
    req.send(null);
}

function drawChart() {

    var texto = document.querySelector('#Leido').innerHTML;
    var fin = texto.match(/(\r|\n)*.*/g);

    var numColumn = 0;
    var mat=new Array(2);
    Imat=0;
    for(i=fin.length-3;(i>=0)&(i>=fin.length-500);i--)
    {
      if (fin[i].length>0)
        {
            var pos_num = fin[i].indexOf("#");
            if (pos_num>0)
                fin[i]=fin[i].substring(0,pos_num-1);
            var temp=fin[i].match(/((-\d+\.\d+)|(\d+\.\d+)|\d+)/g);
            if (temp != null)
            {
                if (numColumn==0)
                    numColumn=temp.length;
                else 
                if (numColumn!=temp.length) break;
                var a = [];
                // primera columna en orden inverso 
                a.push(fin.length-3-Imat);
                for(j=0;j<numColumn;j++)
                    a.push(parseFloat(temp[j]));
                mat[Imat]=a;
                Imat++;
            }
        }
    };
// Se aumenta la primera columna
numColumn++;

mat2 = new Array(2);
if (Imat==0)
    mat2[0]=[0,0];
    mat2[1]=mat2[0];
if (Imat==1)
{mat2[0]=mat[0];
mat2[1]=mat[0];}
else
for (i=0;i<Imat;i++) mat2[i]=mat[Imat-i-1];

var data = new google.visualization.DataTable();
data.addColumn('number', 'num');
for (i=1;i<mat2[0].length;i++)
{
data.addColumn('number', 'A'+i);
}

data.addRows(mat2);
var contiene_grafica = document.getElementById('line_top_x');

var options = {
chart: {
  title: 'Datos ',
  subtitle: 'puerto serial'
},
width: contiene_grafica.clientWidth*0.95,
height: contiene_grafica.clientHeight*0.85,
axes: {
  x: {
    0: {side: 'bottom'}
  }
}
};

var chart = new google.charts.Line(document.getElementById('line_top_x'));

chart.draw(data, google.charts.Line.convertOptions(options));

  }