var mat = [];
var textoFaltante = '';
var textoAingresar='';
var chart;

google.charts.load('current', {'packages':['line']});
google.charts.setOnLoadCallback(drawChart);

document.addEventListener('DOMContentLoaded', () => {
    setInterval(count, 500);
    });

window.onload=function(){
    var A = document.getElementById("baudios");
    A.addEventListener("change", function(){
        b = document.getElementById("baudios");
        var req = new XMLHttpRequest();
        req.open('GET', '\\'+b.options[b.selectedIndex].value, true);
        req.send(null);
        document.querySelector('#Estado').innerHTML=b.options[b.selectedIndex].value;
    });
}


function count() {
    var req = new XMLHttpRequest();
    req.open('GET', url_estado, true);
    req.onreadystatechange = function (aEvt) {
        if (req.readyState === req.DONE) {
            document.querySelector('#Estado').innerHTML=req.responseText;
            };
    };
    req.send(null);
    var req2 = new XMLHttpRequest();
    var verifica_fechaHora = fechaHora;
    req2.open('GET', url_leer+fechaHora, true);
    req2.responseType = 'json'; 
    req2.onreadystatechange = function (aEvt) {
        if (req2.readyState === req2.DONE) {
            const jsonObj = req2.response;
            // Verificación para no duplicar datos
            if (verifica_fechaHora===fechaHora){
                // document.querySelector('#Leido').innerHTML+=jsonObj['texto'];
                fechaHora = jsonObj['fechaHora'].slice(1,-1);
                textoAingresar=jsonObj['texto'];
                if (textoAingresar!="")
                {
                document.querySelector('#Leido').innerHTML+=textoAingresar;
                drawChart();
                };
            };
            };
    };
    req2.send(null);

    if(document.querySelector('#AutoScroll').checked) {
        var textarea = document.getElementById("Leido");
        textarea.scrollTop = textarea.scrollHeight;
        };
        
}

function Borrar() {
    document.querySelector('#Leido').innerHTML='';
    mat = [];
    textoFaltante = '';
    textoAingresar='';
    drawChart();
    var req = new XMLHttpRequest();
    req.open('GET', url_limpiarSalida, true);
    req.send(null);
}

function download(data, filename, type) {
    var file = new Blob([data], {type: type});
    if (window.navigator.msSaveOrOpenBlob) // IE10+
        window.navigator.msSaveOrOpenBlob(file, filename);
    else { // Others
        var a = document.createElement("a"),
                url = URL.createObjectURL(file);
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        setTimeout(function() {
            document.body.removeChild(a);
            window.URL.revokeObjectURL(url);  
        }, 0); 
    }
}

function Grabar() {
/*    var req = new XMLHttpRequest();
    req.open('GET', url_grabarSalida, true);
    req.onreadystatechange = function (aEvt) {
        if (req.readyState === req.DONE) {                       
            download(req.responseText,"Datos.txt",{type: "text/plain;charset=utf-8"});
            };
    };
    req.send(null);*/

    download(document.querySelector('#Leido').innerHTML,"Datos.txt",{type: "text/plain;charset=utf-8"});
}
    
function IniFin() {
    var req = new XMLHttpRequest();
    if (document.querySelector('#IniFin').innerHTML=="Iniciar"){
        var idbaudios = document.getElementById("baudios");
        var enlace = idbaudios.options[idbaudios.selectedIndex].value;

        req.open('GET', enlace, true);
        document.querySelector('#IniFin').innerHTML="Finalizar";
        document.querySelector('#baudios').disabled=true;
    }else{
        req.open('GET', url_fin, true);
        document.querySelector('#IniFin').innerHTML="Iniciar";                   
        document.querySelector('#baudios').disabled=false;
    }
    req.send(null);
}



function drawChart() {

    var nuevoTexto = textoFaltante + textoAingresar;
    var pos = Math.max(nuevoTexto.lastIndexOf('\r'),nuevoTexto.lastIndexOf('\n'))
    textoFaltante =  nuevoTexto.substring(pos);
    nuevoTexto = nuevoTexto.substring(0,pos);
    var fin = nuevoTexto.match(/(\r|\n)*.*/g);

    for(i=0;i<fin.length;i++)
    {
        if (fin[i].length>0)
            {
                var pos_num = fin[i].indexOf("#");
                if (pos_num>0)
                    fin[i]=fin[i].substring(0,pos_num-1);
    
            var temp=fin[i].match(/((-\d+\.\d+)|(\d+\.\d+)|(\d+))/g);
            var a = [];

            if (temp != null)
            {
                if ((mat.length==0)||(mat[0].length!=temp.length+1))
                    {
                    a.push(0);
                    mat.splice(0,mat.length);
                    }
                else {
                    a.push(mat[mat.length-1][0]+1);
                }
                for(j=0;j<temp.length;j++)
                    a.push(parseFloat(temp[j]));
                mat.push(a);
            }
        }
    }

    if (mat.length>500)
      mat.splice(0,mat.length-500);


var data = new google.visualization.DataTable();
//data.addColumn('number', 'num');
data.addColumn('number', '');

if (mat.length>0)
{
  for (i=1;i<mat[0].length;i++)
  {
    //data.addColumn('number', 'A'+i);
    data.addColumn('number', '');
  }
  data.addRows(mat);
}
else
{
  var temp=[];
  temp[0]=[0,0];
  temp[1]=[0,0];
  //data.addColumn('number', 'A');
  data.addColumn('number', '');
  data.addRows(temp);
}

var contiene_grafica = document.getElementById('line_top_x');

var options = {
chart: {
    title: '',
    subtitle: ''

  //title: 'Datos ',
  //subtitle: 'puerto serial'
},
width: contiene_grafica.clientWidth*0.95,
height: contiene_grafica.clientHeight*0.85,
axes: {
  x: {
    0: {side: 'bottom'}
  }
}
};
if (typeof chart === 'undefined')
   chart = new google.charts.Line(document.getElementById('line_top_x'));

chart.draw(data, google.charts.Line.convertOptions(options));

  }