document.addEventListener('DOMContentLoaded', () => {
    setInterval(count, 500);
    });

window.onload=function(){
    var A = document.getElementById("baudios");
    A.addEventListener("change", function(){
        b = document.getElementById("baudios");
        var req = new XMLHttpRequest();
        req.open('GET', '\\'+b.options[b.selectedIndex].value, true);
        req.send(null);
        document.querySelector('#Estado').innerHTML=b.options[b.selectedIndex].value;
    });
}


function count() {
    var req = new XMLHttpRequest();
    req.open('GET', url_estado, true);
    req.onreadystatechange = function (aEvt) {
        if (req.readyState === req.DONE) {
            document.querySelector('#Estado').innerHTML=req.responseText;
            };
    };
    req.send(null);
    var req2 = new XMLHttpRequest();
    req2.open('GET', url_leer+fechaHora, true);
    req2.responseType = 'json'; 
    req2.onreadystatechange = function (aEvt) {
        if (req2.readyState === req2.DONE) {
            const jsonObj = req2.response;
            document.querySelector('#Leido').innerHTML+=jsonObj['texto'];
            fechaHora = jsonObj['fechaHora'].slice(1,-1);
            };
    };
    req2.send(null);

    if(document.querySelector('#AutoScroll').checked) {
        var textarea = document.getElementById("Leido");
        textarea.scrollTop = textarea.scrollHeight;
        };
}

function Borrar() {
    document.querySelector('#Leido').innerHTML='';
    var req = new XMLHttpRequest();
    req.open('GET', url_limpiarSalida, true);
    req.send(null);
}

function download(data, filename, type) {
    var file = new Blob([data], {type: type});
    if (window.navigator.msSaveOrOpenBlob) // IE10+
        window.navigator.msSaveOrOpenBlob(file, filename);
    else { // Others
        var a = document.createElement("a"),
                url = URL.createObjectURL(file);
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        setTimeout(function() {
            document.body.removeChild(a);
            window.URL.revokeObjectURL(url);  
        }, 0); 
    }
}

function Grabar() {
/*    var req = new XMLHttpRequest();
    req.open('GET', url_grabarSalida, true);
    req.onreadystatechange = function (aEvt) {
        if (req.readyState === req.DONE) {                       
            download(req.responseText,"Datos.txt",{type: "text/plain;charset=utf-8"});
            };
    };
    req.send(null);*/

    download(document.querySelector('#Leido').innerHTML,"Datos.txt",{type: "text/plain;charset=utf-8"});
}
    
function IniFin() {
    var req = new XMLHttpRequest();
    if (document.querySelector('#IniFin').innerHTML=="Iniciar"){
        var idbaudios = document.getElementById("baudios");
        var enlace = idbaudios.options[idbaudios.selectedIndex].value;

        req.open('GET', enlace, true);
        document.querySelector('#IniFin').innerHTML="Finalizar";
        document.querySelector('#baudios').disabled=true;
    }else{
        req.open('GET', url_fin, true);
        document.querySelector('#IniFin').innerHTML="Iniciar";                   
        document.querySelector('#baudios').disabled=false;
    }
    req.send(null);
}
