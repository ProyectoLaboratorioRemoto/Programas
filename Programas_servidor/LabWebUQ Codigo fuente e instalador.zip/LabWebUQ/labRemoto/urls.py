from django.urls import path
from . import views
 
# url patterns
app_name = 'labRemoto'

urlpatterns = [
    path("", views.index, name="index"),
    path("estadoArchivo", views.estadoArchivo, name="estadoArchivo"),
    path("practica", views.practica, name="practica"),    
    path("camara", views.camara, name="camara"),
    path("figura", views.figura, name="figura"),
    path("<int:baud>", views.inicio, name="inicio"),
    path("fin", views.fin, name="fin"),
    path("estado", views.estado, name="estado"),
    path("enviar", views.enviar, name="enviar"),
    path("leer", views.leer, name="leer"),
    path("leer/<str:fechaHora>", views.leerdesde, name="leerdesde"),
    path("limpiarSalida", views.limpiarSalida, name="limpiarSalida"),
    path("grabarSalida", views.grabarSalida, name="grabarSalida"),
    path("CargarArchivo", views.pedirCargarArchivo, name="pedirCargarArchivo"),
]
