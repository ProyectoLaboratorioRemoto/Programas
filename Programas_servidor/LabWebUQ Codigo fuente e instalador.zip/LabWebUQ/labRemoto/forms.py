from django import forms
from .models import Archivo_trabajo

#DataFlair #File_Upload
class Subir_Archivo_Form(forms.ModelForm):
    class Meta:
        model = Archivo_trabajo
        fields = [
        'archivo_out'
        ]