from django.contrib import admin

# Register your models here.
from .models import Planta, Lectura,Escritura,Archivo_trabajo
 
admin.site.register(Planta)
admin.site.register(Lectura)
admin.site.register(Escritura)
admin.site.register(Archivo_trabajo)