from django.core.exceptions import ValidationError
 
def validate_file_size(value):
    filesize= value.size
    
    # 10Megas : 10485760 = 10 * 1024 * 1024 
    if filesize > 10485760:
        raise ValidationError("El tamaño máximo del archivo es 10MB")
    else:
        return value

def valid_extension(value):
    if not value.name.endswith('.out'):
        raise ValidationError("Solo archivos .out")

    # if (not value.name.endswith('.png') and
    #     not value.name.endswith('.jpeg') and 
    #     not value.name.endswith('.gif') and
    #     not value.name.endswith('.bmp') and 
    #     not value.name.endswith('.jpg')):
    #     raise ValidationError("Archivos permitidos: .jpg, .jpeg, .png, .gif, .bmp")

