from django.http import StreamingHttpResponse, HttpResponse, HttpResponseRedirect
from django.shortcuts import render, redirect
from django.http import JsonResponse
from django.urls import reverse
from django.views.decorators.clickjacking import xframe_options_exempt
import json    
import numpy
import cv2
import time
from django.contrib.auth.models import User
from cita.models import *
from cita.views import encuentra_siguiente_practica
from .forms import Subir_Archivo_Form
from django.utils.http import urlencode
import numpy as np

import matplotlib
matplotlib.use('Agg')
from matplotlib import pyplot as plt
import urllib.request

from datetime import datetime,timedelta
from .models import *
Opcbaudios = [300,1200,2400,4800,9600,19200,38400,57600,74880,115200,230400,500000,1000000,2000000]


# Create your views here.

class SystemImage(object):
    def __init__(self,puerto):
        # self.cam = VideoCamera()
        if puerto=='COM16':
            self.url = 'http://172.16.24.213/Streaming/channels/1/picture'
        elif puerto=='COM14':
            self.url = 'http://172.16.24.120/Streaming/channels/1/picture'
        elif puerto=='COM12':
            self.url = 'http://172.16.24.122/Streaming/channels/1/picture'
        else:
            self.url = ''
        self.num_cam = 0

        # filas [0:480], columnas [0:640]
        if puerto=='COM14':
            self.min_filas = 0.0
            self.max_filas = 1
            self.min_colum = 0.5
            self.max_colum = 0.68
        else:
            self.min_filas = 0
            self.max_filas = 1
            self.min_colum = 0
            self.max_colum = 1

        self.Inicio = datetime.now()
        # self.ActualLec = datetime.now()

    def __del__(self):
        pass
        # del self.cam

    def get_frame(self):
        auth_user='LabWEBUQ'
        auth_passwd='LabWEBUQ2021'

        passman = urllib.request.HTTPPasswordMgrWithDefaultRealm()
        passman.add_password(None, self.url, auth_user, auth_passwd)
        authhandler = urllib.request.HTTPDigestAuthHandler(passman)
        opener = urllib.request.build_opener(authhandler)
        urllib.request.install_opener(opener)
        resp = urllib.request.urlopen(self.url)
        self.frame = resp.read()

        # recorte de imagen?
        if True:
            image = np.asarray(bytearray(self.frame), dtype="uint8")
            image = cv2.imdecode(image, cv2.IMREAD_COLOR)
            t = image.shape
            image = image[round(t[0]*self.min_filas):round(t[0]*self.max_filas),round(t[1]*self.min_colum):round(t[1]*self.max_colum)]
            ret, jpeg = cv2.imencode('.jpg', image)
            self.frame = jpeg.tobytes()
        return self.frame

    def gencam(self):
        # num_cam permite que solo haya una conexión a la imagen de la cámara
        # si self.num_cam incrementa en mas de 1 es que hay mas de una solicitud a la imagen
        if self.url=='':
            frame = b'imagen'
            return (b'--frame\r\n'
                b'Content-Type: image/jpeg\r\n\r\n' + frame  + b'\r\n\r\n')
        self.num_cam = 0
        num_cam = self.num_cam
        while num_cam == self.num_cam:
            self.num_cam = self.num_cam+1            
            num_cam = num_cam+1
            frame = self.get_frame()
            yield (b'--frame\r\n'
                b'Content-Type: image/jpeg\r\n\r\n' + frame  + b'\r\n\r\n')
            time.sleep(0.1)
        # Aquí se debe adicionar enviar un boton de continuar en la imagen de la cámara


class Figura():
    def __init__(self):
        self.x1 = numpy.array([])
        self.y1 = numpy.array([[]])
        self.texto=""
        self.Ultimo = datetime.now()

    def __del__(self):
        pass
 
    def actualiza(self,texto):
        self.texto += texto
        PosEnter=self.texto.find('\n')
        while(PosEnter!=-1):
            Linea = self.texto[0:PosEnter].split()
            NumEnLin = numpy.array([])
            for L in Linea:
                try:
                    NumEnLin = numpy.concatenate([NumEnLin,[float(L)]])
                except:
                    pass
            if (NumEnLin.shape[0]==0):
                self.x1 = numpy.array([])
                self.y1 = numpy.array([[]])
            else:
                if (NumEnLin.shape[0]==self.y1.shape[1]):
                    self.y1=numpy.concatenate([self.y1,[NumEnLin]])
                    self.x1=numpy.concatenate([self.x1,[self.x1[-1] + 1]])
                else:
                    self.x1 = numpy.array([0])
                    self.y1 = numpy.array([NumEnLin])
            self.texto=self.texto[PosEnter+1:]
            PosEnter=self.texto.find('\n')
        self.x1=self.x1[-500:]
        self.y1=self.y1[-500:]
 
    def genfig(self):
        while True:
            frame = self.figura()
            yield (b'--frame\r\n'
                    b'Content-Type: image/jpeg\r\n\r\n' + frame  + b'\r\n\r\n')
            time.sleep(0.1)

    def figura(self):
        fig = plt.figure()
        ax = fig.add_subplot(1,1,1)
        # ax.set_title('A tale of 2 subplots')
        # ax.set_ylabel('Damped oscillation')
        for k in range(self.y1.shape[1]):
            ax.plot(self.x1, self.y1[:,k], 'o-')
        fig.canvas.draw()
 
        img = numpy.fromstring(fig.canvas.tostring_rgb(), dtype=numpy.uint8, sep='')
        img  = img.reshape(fig.canvas.get_width_height()[::-1] + (3,))
        img = cv2.resize(img  , (400, 200))
        ret, jpeg = cv2.imencode('.jpg', img)
        plt.close(fig)
        return jpeg.tobytes()

plantaImagen = {}
plantafig = {}

for p in Planta.objects.all(): 
    plantaImagen[p.id] = SystemImage(p.puerto)
    plantafig[p.id] = Figura()

def figura(request):
    try:
        planta_id = int(request.session['planta_id'])
    except:
        loginurl = reverse('login')+'?'+urlencode({'next': request.path})
        return redirect(loginurl)
        # return render(request, "usuario/login.html", {"message": None, "procedencia":"labRemoto:index"})
    return StreamingHttpResponse(plantafig[planta_id].genfig(), content_type="multipart/x-mixed-replace;boundary=frame")

 
def camara(request):
    try:
        planta_id = int(request.session['planta_id'])
    except:
        loginurl = reverse('login')+'?'+urlencode({'next': request.path})
        return redirect(loginurl)
        # return render(request, "usuario/login.html", {"message": None, "procedencia":"labRemoto:index"})
    if True: # plantaImagen[planta_id].imagen_disponible():
        try:
            return StreamingHttpResponse(plantaImagen[planta_id].gencam(), content_type="multipart/x-mixed-replace;boundary=frame")
        except:  # This is bad! replace it with proper handling
            return HttpResponse("No hay imagen")
    else:
        return HttpResponse("Cámara cerrada")

def index(request):
    if not request.user.is_authenticated:
        loginurl = reverse('login')+'?'+urlencode({'next': request.path})
        return redirect(loginurl)
    user = User.objects.get(username=request.user.username)
    horario_lab_virtual,Esta_activo = encuentra_siguiente_practica(user)
    if not horario_lab_virtual or not Esta_activo:
        return HttpResponseRedirect(reverse('citas:index'))
    fecha_fin = horario_lab_virtual.tiempo_inicio + timedelta(hours=float(horario_lab_virtual.duracion))
    request.session['planta_id'] = horario_lab_virtual.planta.id
    request.session['Activo'] = Esta_activo
    P = Planta.objects.get(id=request.session['planta_id'])

    Archivo = Archivo_trabajo.objects.filter(planta=P,tiempo__gte =horario_lab_virtual.tiempo_inicio).order_by('tiempo').last()

    # # # quitar este código cuando se inicien las citas
    # Archivo = Archivo_trabajo.objects.filter(planta=P).order_by('tiempo').last()
    # # # Hasta aquí lo de quitar
   

    if Archivo:
        if P.Solicitud:
            return HttpResponseRedirect(reverse('labRemoto:practica'))
    P.Solicitud = False
    P.save()
    plantafig[P.id].Ultimo = datetime.now()

    form = Subir_Archivo_Form()
    if request.method == 'POST':
        form = Subir_Archivo_Form(request.POST, request.FILES)
        if form.is_valid():
            user_pr = form.save(commit=False)
            user_pr.archivo_out = request.FILES['archivo_out']
            file_type = user_pr.archivo_out.url.split('.')[-1]
            file_type = file_type.lower()
            user_pr.planta=P
            user_pr.save()
            # return render(request, 'labRemoto/details.html', {'user_pr': user_pr})
            return HttpResponseRedirect(reverse('labRemoto:index'))
            # return HttpResponse("Archivo guardado " + user_pr.archivo_out.url)
    context = {"form": form,"fecha_fin":fecha_fin,"Archivo":Archivo,'nombrePractica':P.nombre}
    return render(request, 'labRemoto/index.html', context)

def practica(request):
    if not request.user.is_authenticated:
        loginurl = reverse('login')+'?'+urlencode({'next': request.path})
        return redirect(loginurl)
    user = User.objects.get(username=request.user.username)
    horario_lab_virtual,Esta_activo = encuentra_siguiente_practica(user)
    if not horario_lab_virtual or not Esta_activo:
        return HttpResponseRedirect(reverse('citas:index'))
    fecha_fin = horario_lab_virtual.tiempo_inicio + timedelta(hours=float(horario_lab_virtual.duracion))
    request.session['planta_id'] = horario_lab_virtual.planta.id
    request.session['Activo'] = Esta_activo
    P = Planta.objects.get(id=request.session['planta_id'])
    Archivo = Archivo_trabajo.objects.filter(planta=P,tiempo__gte =horario_lab_virtual.tiempo_inicio).order_by('tiempo').last()
    # # # # quitar este código cuando se inicien las citas
    # Archivo = Archivo_trabajo.objects.filter(planta=P).order_by('tiempo').last()
    # # # # Hasta aquí lo de quitar

    if not Archivo:
        return HttpResponseRedirect(reverse('labRemoto:index'))

    if P.Solicitud:
        TextoEnBoton = "Finalizar"
    else:
        TextoEnBoton = "Iniciar"
    baudios = P.baudios

    TextoLeidoInicial=""

    # Comando para no buscar caracteres leidos anteriores, quitar cuando esté arreglado
    plantaImagen[P.id].Inicio = datetime.now()
    # hasta aquí lo de quitar

    if plantaImagen[P.id].Inicio<=horario_lab_virtual.tiempo_inicio:
        plantaImagen[P.id].Inicio=horario_lab_virtual.tiempo_inicio
    else:
        Lec = Lectura.objects.filter(tiempo__gte = plantaImagen[P.id].Inicio,planta = P).order_by("tiempo")
        for t in Lec:
            TextoLeidoInicial += t.Caracteres

    context = {"TextBot":TextoEnBoton,"baudios":baudios,"Opcbaudios":Opcbaudios,"usuario":user.username,"fecha_fin":fecha_fin,
                'fechaHora':json.dumps(datetime.now().isoformat())[1:-1], "TextoLeidoInicial":TextoLeidoInicial,
                'nombrePractica':P.nombre}
    return render(request,"labRemoto/practica.html",context)

def estadoArchivo(request):
    if not request.user.is_authenticated:
        return HttpResponse("Usuario sin ingresar")
    # return JsonResponse('Enviado',safe=False)
    P = Planta.objects.get(id=request.session['planta_id'])
    Archivo = Archivo_trabajo.objects.filter(planta=P).order_by('tiempo').last()
    if Archivo:
        if Archivo.error:
            texto = "Error subiendo archivo:"
        elif not Archivo.se_ha_subido:
            texto = "Subiendo archivo:"
        else:
            texto = "Archivo subido:"
    else:
        texto = "No se ha cargado archivo"
    return HttpResponse(texto)


def index2(request):
    if not request.user.is_authenticated:
        loginurl = reverse('login')+'?'+urlencode({'next': request.path})
        return redirect(loginurl)
        # return render(request, "usuario/login.html", {"message": None, "procedencia":"labRemoto:index"})
    user = User.objects.get(username=request.user.username)
    horario_lab_virtual,Esta_activo = encuentra_siguiente_practica(user)
    if not horario_lab_virtual or not Esta_activo:
        return HttpResponseRedirect(reverse('citas:index'))

    fecha_fin = horario_lab_virtual.tiempo_inicio + timedelta(hours=float(horario_lab_virtual.duracion))

    request.session['planta_id'] = horario_lab_virtual.planta.id
    request.session['Activo'] = Esta_activo

    P = Planta.objects.get(id=request.session['planta_id'])

    if P.Solicitud:
        TextoEnBoton = "Finalizar"
    else:
        TextoEnBoton = "Iniciar"
    baudios = P.baudios

    TextoLeidoInicial=""
    if plantaImagen[P.id].Inicio<horario_lab_virtual.tiempo_inicio:
        plantaImagen[P.id].Inicio=horario_lab_virtual.tiempo_inicio
    else:
        Lec = Lectura.objects.filter(tiempo__gte = plantaImagen[P.id].Inicio,planta = P).order_by("tiempo")
        for t in Lec:
            TextoLeidoInicial += t.Caracteres

    context = {"TextBot":TextoEnBoton,"baudios":baudios,"Opcbaudios":Opcbaudios,"usuario":user.username,"fecha_fin":fecha_fin,
                'fechaHora':json.dumps(datetime.now().isoformat())[1:-1], "TextoLeidoInicial":TextoLeidoInicial}
    return render(request,"labRemoto/index.html",context)
 
def inicio(request,baud):
    if not request.user.is_authenticated:
        return HttpResponse("Usuario sin ingresar")
    horario_lab_virtual,Esta_activo = encuentra_siguiente_practica(request.user)
    P = Planta.objects.get(id=request.session['planta_id'])
    if Esta_activo and request.session['planta_id'] == horario_lab_virtual.planta.id:
        if baud in Opcbaudios:
            P.baudios=baud
            P.Solicitud=True
            P.save()
            Texto="Inicio de Comunicación"
        else:
            Texto="Opcion no permitida"
    else:
        Texto="No hay práctica activa"
    return HttpResponse(Texto)


def fin(request):
    if not request.user.is_authenticated:
        return HttpResponse("Usuario sin ingresar")
    horario_lab_virtual,Esta_activo = encuentra_siguiente_practica(request.user)
    if Esta_activo:
        P = Planta.objects.get(id=request.session['planta_id'])
        P.Solicitud=False
        P.save()
    return HttpResponse("Fin de Comunicación")
 
def estado(request):
    if not request.user.is_authenticated:
        return HttpResponse("Usuario sin ingresar")
    # return JsonResponse('Enviado',safe=False)
    P = Planta.objects.get(id=request.session['planta_id'])
    # planta_id = int(request.session['planta_id'])
    # plantaImagen[planta_id].next()
    Archivo = Archivo_trabajo.objects.filter(planta=P).order_by('tiempo').last()
    if Archivo:
        if Archivo.error:
            texto = "Error subiendo archivo"
        elif not Archivo.se_ha_subido:
            texto = "Subiendo archivo"
        elif P.Solicitud==P.Encendido:
            if P.Solicitud:
                texto = "Comunicación Activa"
            else:
                texto = "Sin comunicación"
        else:
            if P.Solicitud:
                texto = "Iniciando comunicación"
            else:
                texto = "Finalizando comunicación"
        texto = texto + "<br /> Archivo: " + Archivo.archivo_out.name
    else:
        texto = "No se ha cargado archivo"
    return HttpResponse(texto)
 
@xframe_options_exempt
def enviar(request):
    if not request.user.is_authenticated:
        return HttpResponse("Usuario sin ingresar")
    if request.method != 'POST':
        context = {
        "Texto":"No se ha grabado",
        "seleccion":"1",
        }
        return render(request,"labRemoto/enviar.html",context)

    horario_lab_virtual,Esta_activo = encuentra_siguiente_practica(request.user)
    P = Planta.objects.get(id=request.session['planta_id'])
    if Esta_activo and request.session['planta_id'] == horario_lab_virtual.planta.id:
        Texto = request.POST['TextoAEnviar']
        if P.Solicitud and P.Encendido:
            if (Texto!=''):
                if request.POST['final']=="1":
                    Texto+=chr(10)
                if request.POST['final']=="2":
                    Texto+=chr(13)
                if request.POST['final']=="3":
                    Texto+=chr(13)+chr(10)

                while (Texto!=''):
                    L = len(Texto)
                    if L>64:
                        E = Escritura(planta=P,Caracteres=Texto[0:64])
                        Texto = Texto[64:]
                    else:
                        E = Escritura(planta=P,Caracteres=Texto)
                        Texto =''
                    E.save()
                context = {
                    "Texto":"Grabado",
                    "seleccion":request.POST['final'],
                    }
            else:
                context = {
                    "Texto":"Sin texto",
                    "seleccion":request.POST['final'],
                    }
        else:
            context = {
                "Texto":"Sin comunicación",
                "seleccion":request.POST['final'],
                }
        return render(request,"labRemoto/enviar.html",context)
    return HttpResponse("Práctica inactiva")

def leer(request):
#     fechaHora = datetime.now()
#     return render(request, "labRemoto/prueba.html",{'fechaHora':json.dumps(datetime.now().isoformat())[1:-1]})
#     P = Planta.objects.get(id=request.session['planta_id'])
#     Lec = Lectura.objects.filter(tiempo__gt = plantaImagen[P.id].ActualLec).order_by("tiempo")
#     actual = plantaImagen[P.id].ActualLec
#     texto = ""
#     for t in Lec:
#         texto += t.Caracteres
#         actual = t.tiempo
#     plantaImagen[P.id].ActualLec = actual
#     plantafig[P.id].actualiza(texto)
    return HttpResponse("funcionando")

def leerdesde(request,fechaHora):
    if not request.user.is_authenticated:
        return HttpResponse("Usuario sin ingresar")
    horario_lab_virtual,Esta_activo = encuentra_siguiente_practica(request.user)
    if Esta_activo and request.session['planta_id'] == horario_lab_virtual.planta.id:
        P = Planta.objects.get(id=request.session['planta_id'])

        # Actualiza valores de gráfica
        Lec = Lectura.objects.filter(tiempo__gt = plantafig[P.id].Ultimo,planta = P).order_by("tiempo")
        texto = ""
        for t in Lec:
            texto += t.Caracteres
            plantafig[P.id].Ultimo = t.tiempo
        plantafig[P.id].actualiza(texto)
        

        # Actualiza valores del cuadro texto
        actual = datetime.strptime(fechaHora, '%Y-%m-%dT%H:%M:%S.%f')
        Lec = Lectura.objects.filter(tiempo__gt = actual,planta = P).order_by("tiempo")
        texto = ""
        for t in Lec:
            texto += t.Caracteres
            actual = t.tiempo
    else:
        texto = ''
        actual=datetime.now()
    return JsonResponse({'texto': texto,'fechaHora':json.dumps(actual.isoformat())})

def limpiarSalida(request):
    if not request.user.is_authenticated:
        return HttpResponse("Usuario sin ingresar")
    P = Planta.objects.get(id=request.session['planta_id'])
    plantaImagen[P.id].Inicio = datetime.now()
    plantafig[P.id].x1 = numpy.array([])
    plantafig[P.id].y1 = numpy.array([[]])
    plantafig[P.id].texto=""
    return HttpResponse("Listo")

def grabarSalida(request):
    if not request.user.is_authenticated:
        return HttpResponse("Usuario sin ingresar")
    P = Planta.objects.get(id=request.session['planta_id'])
    Lec = Lectura.objects.filter(tiempo__gt = plantaImagen[P.id].Inicio).order_by("tiempo")
    texto = ""
    for t in Lec:
        texto += t.Caracteres
    return HttpResponse(texto)

@xframe_options_exempt
def pedirCargarArchivo(request):
    if not request.user.is_authenticated:
        return HttpResponse("Usuario sin ingresar")
    P = Planta.objects.get(id=request.session['planta_id'])
    form = Subir_Archivo_Form()
    if request.method == 'POST':
        form = Subir_Archivo_Form(request.POST, request.FILES)
        if form.is_valid():
            user_pr = form.save(commit=False)
            user_pr.archivo_out = request.FILES['archivo_out']
            file_type = user_pr.archivo_out.url.split('.')[-1]
            file_type = file_type.lower()
            user_pr.planta=P
            user_pr.save()
            # return render(request, 'labRemoto/details.html', {'user_pr': user_pr})
            return HttpResponseRedirect(reverse('labRemoto:pedirCargarArchivo'))
            # return HttpResponse("Archivo guardado " + user_pr.archivo_out.url)
    context = {"form": form}
    return render(request, 'labRemoto/pedir_archivo.html', context)
