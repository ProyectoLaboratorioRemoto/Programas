from django.db import models
from .validators import validate_file_size,valid_extension

# Create your models here.
class Planta(models.Model):
    nombre = models.CharField(max_length=64)
    
    puerto = models.CharField(max_length=10)
    baudios = models.IntegerField(default=9600)
    Solicitud = models.BooleanField(default=False)
    Encendido = models.BooleanField(default=False)
    def __str__(self):
        #return f"{self.id}:{self.nombre} - {self.baudios} petición {self.Solicitud} estado {self.Encendido}"
        #return f"{self.puerto}:{self.nombre}"
        return f"{self.nombre}"
 
 
class Lectura(models.Model):
    tiempo = models.DateTimeField(auto_now=True)
    planta = models.ForeignKey(Planta, on_delete=models.CASCADE, related_name="PlantaLec")
    Caracteres = models.CharField(max_length=64)
    def __str__(self):
        return f"{self.id}:{self.tiempo}:{self.planta} - {self.Caracteres}"


class Escritura(models.Model):
    tiempo = models.DateTimeField(auto_now=True)
    planta = models.ForeignKey(Planta, on_delete=models.CASCADE, related_name="PlantaEsc")
    Caracteres = models.CharField(max_length=64)
    def __str__(self):
        return f"{self.id}:{self.tiempo}:{self.planta} - {self.Caracteres}"

class Archivo_trabajo(models.Model):
    tiempo = models.DateTimeField(auto_now=True)
    planta = models.ForeignKey(Planta, on_delete=models.CASCADE, related_name="PlantaArc")
    archivo_out = models.FileField(validators=[validate_file_size,valid_extension])
    se_ha_subido = models.BooleanField(default=False)
    error = models.BooleanField(default=False)
    Datos_error = models.CharField(max_length=256,default="")
    def __str__(self):
        return f"{self.planta.nombre} archivo {self.archivo_out.name} ruta {self.archivo_out.url}"