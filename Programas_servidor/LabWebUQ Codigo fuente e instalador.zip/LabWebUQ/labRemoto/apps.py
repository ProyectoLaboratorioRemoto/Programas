from django.apps import AppConfig


class LabremotoConfig(AppConfig):
    name = 'labRemoto'
