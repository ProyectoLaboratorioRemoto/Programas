from django.urls import path
from . import views
 
# url patterns
app_name = 'citas'  
urlpatterns = [
    path("", views.index, name="index"),
    path("<int:planta_id>", views.mostrar_opciones_view, name="mostrar_opciones"),
    path("asignar/<int:planta_id>", views.asignar_cita_view, name="asignar_cita"),
    path("borrar/<int:planta_id>/<int:year>/<int:month>/<int:day>/<int:hour>/<int:minute>", views.borrar_cita_view, name="borrar_cita"),
    path("registra_email", views.registra_email, name="registra_email"),
    path("asigna_practica/<int:practica_id>", views.asigna_practica, name="asigna_practica"),   
    path("crea_horarios/<int:planta_id>", views.crea_horarios, name="crea_horarios"),   
    path("verifica_cruces", views.verifica_cruces, name="verifica_cruces"),   
    path("admin", views.admin, name="admin"),   
]
