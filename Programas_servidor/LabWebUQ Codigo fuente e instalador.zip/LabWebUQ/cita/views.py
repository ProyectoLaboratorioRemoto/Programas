from django.contrib.auth import authenticate, login, logout
from django.shortcuts import render, redirect
from .models import *
from django.contrib.auth.models import User
from datetime import datetime,timedelta
from django.http import HttpResponse, HttpResponseRedirect
from django.urls import reverse
from django.utils.http import urlencode

# Create your views here.
def encuentra_siguiente_practica(user):
    """ Encuentra la próxima práctica a realizarse e indica si dicha
    práctica está corriendo en este momento"""
    plantas_usuario = Practica.objects.filter(usuario__email=user.email).values('planta')

    # busca la última datetime antes del presente, y luego verifica si la duración no se ha vencido
    programacion = Horario.objects.filter(planta__in=plantas_usuario,usuario__email=user.email,tiempo_inicio__lt = datetime.now()).order_by('tiempo_inicio').last()
    
    # # Quitar esta parte cuando active usuarios con citas
    # if user.email=='jaibercardona@uniquindio.edu.co':
    #     P = Planta.objects.get(puerto='COM4')
    #     programacion = Horario(planta=P,usuario=EmailTrabajo.objects.filter(email=user.email).first(),tiempo_inicio=datetime.now()-timedelta(hours=float(5)),duracion=10)
    # if user.username=='u1':
    #     P = Planta.objects.get(puerto='COM6')
    #     programacion = Horario(planta=P,usuario=EmailTrabajo.objects.filter(email=user.email).first(),tiempo_inicio=datetime.now()-timedelta(hours=float(5)),duracion=10)
    # if user.username=='u2':
    #     P = Planta.objects.get(puerto='COM8')
    #     programacion = Horario(planta=P,usuario=EmailTrabajo.objects.filter(email=user.email).first(),tiempo_inicio=datetime.now()-timedelta(hours=float(5)),duracion=10)
    # # Hasta aquí lo de quitar
    
    
    if programacion:
        if programacion.tiempo_inicio+timedelta(hours=float(programacion.duracion))>datetime.now():
            # si la duración del último iniciado no se ha vencido entonces esa es la práctica actual 
            # y se envía True porque se está realizando en este momento
            return programacion,True

    # si no hay ninguno vigente se busca el próximo a ejecutarse. 
    programacion = Horario.objects.filter(planta__in=plantas_usuario,usuario__email=user.email,tiempo_inicio__gt = datetime.now()).order_by('tiempo_inicio').first()

    # se devuelve la próxima práctica a ejecutarse con un False porque aún no se está realizando
    return programacion,False

def horarios_programados(user):
    plantas_usuario = Practica.objects.filter(usuario__email=user.email)
    horarios = []
    for p in plantas_usuario:
        temp = Horario.objects.filter(planta=p.planta,usuario__email=user.email,tiempo_inicio__gt = datetime.now())
        if temp:
            horarios+=[temp[0]]
    return horarios

def practicas_por_programar(user):
    plantas_usuario = Practica.objects.filter(usuario__email=user.email)
    practicas = []
    for p in plantas_usuario:
        temp = Horario.objects.filter(planta=p.planta,usuario__email=user.email,tiempo_inicio__gt = datetime.now())
        if not temp:
            practicas+=[p.planta]
    return practicas

def index(request):
    if not request.user.is_authenticated:
        loginurl = reverse('login')+'?'+urlencode({'next': request.path})
        return redirect(loginurl)
        # return render(request, "usuario/login.html", {"message": None, "procedencia":"citas:index"})
    user = User.objects.get(username=request.user.username)
    plantas_usuario = Practica.objects.filter(usuario__email=user.email).values('planta')

    siguiente,activo = encuentra_siguiente_practica(user)

    context = {
        "plantas_usuario":plantas_usuario,
        "siguiente":siguiente,
        "activo":activo,
        "horarios_programados":horarios_programados(user),
        "practicas_por_programar":practicas_por_programar(user),
        "usuario": user.email,
    }
    return render(request, "citas/index.html", context)

def mostrar_opciones_view(request,planta_id):
    if not request.user.is_authenticated:
        loginurl = reverse('login')+'?'+urlencode({'next': request.path})
        return redirect(loginurl)
        # return render(request, "usuario/login.html", {"message": None, "procedencia":"citas:index"})
    user = User.objects.get(username=request.user.username)
    try:
        practica = Practica.objects.get(planta__id=planta_id,usuario__email=user.email)
    except:
        return HttpResponseRedirect(reverse("citas:index"))
    planta = practica.planta
    
    # Busca horarios disponibles que no se crucen con el usuario así sea en otras plantas.
    Horarios_Usuario = Horario.objects.filter(usuario__email=user.email,tiempo_inicio__gt = datetime.now())
    Horarios_Disponibles= Horario.objects.filter(planta=planta,usuario=None,tiempo_inicio__gt = datetime.now()).order_by('tiempo_inicio')
    for h in Horarios_Usuario:
        Horarios_Disponibles = Horarios_Disponibles.exclude(tiempo_inicio__gte=h.tiempo_inicio,tiempo_inicio__lt=h.tiempo_inicio + timedelta(hours=float(h.duracion)))    

    context = {
        "horario_actual" : Horario.objects.filter(planta=planta,usuario__email=user.email,tiempo_inicio__gt = datetime.now()),
        # "horarios_disponibles" : Horario.objects.filter(planta=planta,usuario=None,tiempo_inicio__gt = datetime.now()).order_by('tiempo_inicio'),
        "horarios_disponibles" : Horarios_Disponibles,
        "usuario": user.email,
        "num_planta":planta_id,
        }

    return render(request, "citas/mostrar_opciones.html", context)

def asignar_cita_view(request,planta_id):
    if request.method == 'POST':
        if not request.user.is_authenticated:
            loginurl = reverse('login')+'?'+urlencode({'next': request.path})
            return redirect(loginurl)
            # return render(request, "usuario/login.html", {"message": None, "procedencia":"citas:index"})
        user = User.objects.get(username=request.user.username)
        planta = Planta.objects.get(id=planta_id)
        if 'horario_seleccionado' in request.POST:
            cita = request.POST['horario_seleccionado'].split()            
            horario = Horario.objects.get(planta=planta,tiempo_inicio__year=int(cita[0]),tiempo_inicio__month=int(cita[1]),
                tiempo_inicio__day=int(cita[2]),tiempo_inicio__hour=int(cita[3]),tiempo_inicio__minute=int(cita[4]))

            # cruce = Horario.objects.filter(usuario__email=user.email,
            #                                 tiempo_inicio__gte=horario.tiempo_inicio,
            #                                 tiempo_inicio__lt=horario.tiempo_inicio + timedelta(hours=float(horario.duracion)))


            if horario.usuario == None:
                paracruces = Horario.objects.filter(usuario__email=user.email,
                                                    tiempo_inicio__gt = datetime.now()-timedelta(hours=10),
                                                    ).exclude(
                                                        tiempo_inicio__gte = horario.tiempo_inicio+timedelta(hours=float(horario.duracion)),
                                                    )
                cruce = False
                for p in paracruces:
                    if p.tiempo_inicio+timedelta(hours=float(p.duracion))>horario.tiempo_inicio:
                        cruce=True
                if not cruce:
                    horarios_a_liberar = Horario.objects.filter(planta=planta,usuario__email=user.email,tiempo_inicio__gt = datetime.now())
                    for hl in horarios_a_liberar:
                        hl.usuario=None
                        hl.save()
                    horario.usuario = EmailTrabajo.objects.filter(email=user.email).first()
                    horario.save()
    return HttpResponseRedirect(reverse("citas:index"))
    
def borrar_cita_view(request,planta_id,year,month,day,hour,minute):
    if request.method == 'POST':
        if not request.user.is_authenticated:
            loginurl = reverse('login')+'?'+urlencode({'next': request.path})
            return redirect(loginurl)
            # return render(request, "usuario/login.html", {"message": None, "procedencia":"citas:index"})
        user = User.objects.get(username=request.user.username)
        planta = Planta.objects.get(id=planta_id)
        horario = Horario.objects.get(planta=planta,tiempo_inicio__year=year,tiempo_inicio__month=month,
            tiempo_inicio__day=day,tiempo_inicio__hour=hour,tiempo_inicio__minute=minute,usuario__email=user.email)
        horario.usuario=None
        horario.save()
    return HttpResponseRedirect(reverse("citas:index"))

def registra_email(request):
    if not request.user.is_authenticated or request.user.email not in ['admin@controluq.online','josegabrielh@uniquindio.edu.co']:
        return redirect('/')
    context = {}
    if request.method == 'POST':
        correos_registrados = []
        correos = request.POST['correos'].split()
        for correo in correos:
            if '@' in correo:
                correo = correo.replace(" ","")
                email,created = EmailTrabajo.objects.get_or_create(email=correo)
                if created:
                    correos_registrados.append(correo)
        context['correos_registrados']=correos_registrados
    return render(request, "citas/registra_email.html", context)

def asigna_practica(request,practica_id):
    if not request.user.is_authenticated or request.user.email not in ['admin@controluq.online','josegabrielh@uniquindio.edu.co']:
        return redirect('/')
    practica = Practica.objects.get(id=practica_id)
    context = {'practica':practica.planta.nombre}
    if request.method == 'POST':
        correos_registrados = []
        correos = request.POST['correos'].split()
        for correo in correos:
            if '@' in correo:
                correo = correo.replace(" ","")
                email,created = EmailTrabajo.objects.get_or_create(email=correo)
                practica.usuario.add(email)
                correos_registrados.append(correo)
        context['correos_registrados']=correos_registrados
    context['practica_id']=practica_id
    return render(request, "citas/asigna_practica.html", context)

def crea_horarios(request,planta_id):
    if not request.user.is_authenticated or request.user.email not in ['admin@controluq.online','josegabrielh@uniquindio.edu.co']:
        return redirect('/')
    planta = Planta.objects.get(id=planta_id)
    context = {'planta':planta}

    if request.method == 'POST':
        horarios_programados = Horario.objects.filter(planta=planta,tiempo_inicio__gt = datetime.now()).order_by('tiempo_inicio')
        mal_formato=[]
        cruces=[]
        horarios_registrados = []
        horarios = request.POST['horarios'].split('\n')
        for horario in horarios:
            campo = horario.split('\t')
            if len(campo)!=3:
                campo = horario.split(' ')
            if len(campo)==3:
                if len(campo[1])==4:
                    campo[1]='0'+campo[1]
                try:
                    inicio = datetime.fromisoformat(campo[0]+'T'+campo[1]+':00')
                    duracion=float(campo[2].replace(',','.'))
                except:
                    mal_formato.append(horario)
                else:
                    if duracion>0 and duracion<10 and inicio>=datetime.now():                        
                        nuevo=Horario(planta=planta,tiempo_inicio=inicio,duracion=duracion)
                        limite = nuevo.tiempo_inicio + timedelta(hours=float(nuevo.duracion))
                        for h in horarios_programados:
                            h_limite=h.tiempo_inicio + timedelta(hours=float(h.duracion))
                            if not (limite<=h.tiempo_inicio or h_limite<=nuevo.tiempo_inicio):
                                cruces.append(horario)
                                break
                        else:
                            nuevo.save()
                            horarios_registrados.append(nuevo)
                    else:
                        mal_formato.append(horario)
            else:
                if len(horario)>0:
                    mal_formato.append(horario)
        context['horarios_registrados']=horarios_registrados
        context['mal_formato']=mal_formato
        context['cruces']=cruces
    context['planta_id']=planta_id
    return render(request, "citas/crea_horarios.html", context)

def verifica_cruces(request):
    if not request.user.is_authenticated or request.user.email not in ['admin@controluq.online','josegabrielh@uniquindio.edu.co']:
        return redirect('/')
    cruces=[]
    plantas = Planta.objects.all()
    for p in plantas:
        horarios = Horario.objects.filter(planta=p,tiempo_inicio__gt = datetime.now()).order_by('tiempo_inicio')
        if horarios:
            anterior = horarios[0]
            limite = anterior.tiempo_inicio + timedelta(hours=float(anterior.duracion))
            for h in horarios[1:]:
                if h.tiempo_inicio<limite:
                    cruces.append(anterior)
                    cruces.append(h)
                if (limite<h.tiempo_inicio + timedelta(hours=float(h.duracion))):
                    anterior = h
                    limite = anterior.tiempo_inicio + timedelta(hours=float(anterior.duracion))
    return render(request, "citas/verifica_cruces.html", {'cruces':cruces})

def admin(request):
    if not request.user.is_authenticated or request.user.email not in ['admin@controluq.online','josegabrielh@uniquindio.edu.co']:
        return redirect('/')
    plantas = Planta.objects.all()
    practicas = Practica.objects.all()
    return render(request, "citas/admin.html", {'practicas':practicas})
