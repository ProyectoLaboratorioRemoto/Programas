from django.contrib import admin
from .models import Practica, Horario, EmailTrabajo

# Register your models here.
admin.site.register(Practica)
admin.site.register(Horario)
admin.site.register(EmailTrabajo)

from django.contrib.auth.models import Group
admin.site.unregister(Group)

from django.contrib.sites.models import Site
admin.site.unregister(Site)

admin.site.site_header = "Laboratorio Web Uniquindio"
admin.site.site_title = "Laboratorio Web Uniquindio"
admin.site.index_title = "Administración"