from django.db import models
from labRemoto.models import Planta
# Create your models here.

class EmailTrabajo(models.Model):
    email = models.EmailField(max_length = 254)
    def __str__(self):
        return f"{self.email}"

class Practica(models.Model):
    # nombre = models.CharField(max_length=64)
    planta = models.ForeignKey(Planta, on_delete=models.CASCADE, related_name="Panta_practica")
    usuario = models.ManyToManyField(EmailTrabajo,  related_name="Usuario_practica")
    def __str__(self):
        return f"{self.planta}"

class Horario(models.Model):
    planta = models.ForeignKey(Planta, on_delete=models.CASCADE, related_name="Panta_horario")
    usuario = models.ForeignKey(EmailTrabajo, on_delete=models.SET_NULL, null=True, blank=True, related_name="Usuario_horario",default=None)
    tiempo_inicio = models.DateTimeField(auto_now=False)
    duracion = models.DecimalField(max_digits=3, decimal_places=2,default=1)
    #tiempo_fin = models.DateTimeField(auto_now=False, null=True,default=None)

    def __str__(self):
        return f"Sistema:{self.planta}-usuario:{self.usuario}-inicio:{self.tiempo_inicio} duracion {self.duracion}"

