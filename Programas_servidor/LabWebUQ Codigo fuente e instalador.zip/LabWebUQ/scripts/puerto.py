"""Django's command-line utility for administrative tasks."""
import subprocess
import os
import sys
import serial, time, msvcrt
from datetime import datetime,timedelta
from labRemoto.models import Planta, Lectura,Escritura,Archivo_trabajo
from cita.models import *

os.environ['LOADTI_PATH']='C:\\ti\\ccs1030\\ccs\\ccs_base\\scripting\\examples\\loadti\\'

def esta_ocupada(planta):
    h = Horario.objects.filter(tiempo_inicio__lt = datetime.now(),planta=planta).order_by('tiempo_inicio').last()
    if h.tiempo_inicio + timedelta(hours=float(h.duracion))>datetime.now():
        return h.usuario!=None
    else:
        return False

def run(*arg):
    if len(arg)<1:
        raise "no indica puerto"
    else:
        puerto=arg[0]

    if puerto=="COM4":
        tarjeta="TI439KTY"
    elif puerto=="COM6":
        tarjeta="TI439CKE"
    elif puerto=="COM8":
        tarjeta="TI1SNVXC"
    elif puerto=="COM10":
        tarjeta="TI1SPS19"
    elif puerto=="COM12":
        tarjeta="TI439BR4"
    elif puerto=="COM14":
        tarjeta="TI1SK8HS"
    elif puerto=="COM16":
        tarjeta="TI1SP5E0"
    else:
        raise "puerto " + puerto + " no es válido"



    D=["C:\\ti\\ccs1030\\ccs\\eclipse\\jre\\bin\\java.exe",
        "-cp",
        "C:\\ti\\ccs1030\\ccs\ccs_base\\DebugServer\\packages\\ti\\dss\\java\\js.jar;C:\\ti\\ccs1030\\ccs\\ccs_base\\DebugServer\\packages\\ti\\dss\\java\\dss.jar",
        "org.mozilla.javascript.tools.shell.Main", 
        "C:\\ti\\ccs1030\\ccs\\ccs_base\\scripting\\examples\\loadti\\main.js",
        "-a",
        "-c", 
        "D:\\LabWebUQ\\Config\\TMS320F28379D-" + tarjeta + ".ccxml",
        "D:\\LabWebUQ\\media\\adc_ex1_soc_software.out",
        # "C:\\Users\\GMA\\Downloads\\adc_ex1_soc_software.out",
        ]

    Ultimo = datetime.now()
    tecla = b' '
    print("Presione x para salir")

    P = Planta.objects.get(puerto=puerto)
    print("Planta:" + P.nombre + " Puerto:"+ P.puerto)

    while tecla!=b'x':
        P = Planta.objects.get(puerto=puerto)
        Archivo = Archivo_trabajo.objects.filter(planta=P).order_by('tiempo').last()

        time.sleep(0.5)
        if Archivo:
            if Archivo.se_ha_subido:
                # P = Planta.objects.get(nombre="COM3")
                if P.Solicitud and P.Encendido:
                    if 'arduino' in locals():
                        if arduino.in_waiting>0:
                            rawString = arduino.read(arduino.in_waiting)
                            Texto = ''
                            for c in rawString:
                                Texto+=chr(c)
                            if len(Texto)>5000:
                                Texto = 'Error, alto número de caracteres recibidos\n'
                            while (Texto!=''):
                                L = len(Texto)
                                if L>64:
                                    L = Lectura(planta=P,Caracteres=Texto[0:64])
                                    Texto = Texto[64:]
                                else:
                                    L = Lectura(planta=P,Caracteres=Texto)
                                    Texto =''
                                L.save()
                        E = Escritura.objects.filter(tiempo__gt = Ultimo,planta=P).order_by("tiempo")
                        texto = ""
                        for t in E:
                            texto += t.Caracteres
                            Ultimo = t.tiempo
                        if (texto!=''):
                            comando = []
                            for c in texto:
                                comando+=[ord(c)]
                            arduino.write(comando)
                    else:
                        P.Encendido=False
                        P.save()

                if P.Solicitud and (not P.Encendido):
                    print("Iniciando Comunicación" + puerto)
                    print("Planta:" + P.nombre + " Puerto:"+ P.puerto)
                    print(datetime.now())
                    if 'arduino' in locals():
                        arduino.close()
                        del arduino
                    else:
                        try:
                            arduino = serial.Serial(P.puerto, P.baudios,timeout=1,write_timeout=10)
                            P.Encendido=True
                            P.save()
                            Ultimo = datetime.now()
                        # except arduino.DoesNotExist:
                        except:
                            print("No se abrió comunicación serial")        


                if (not P.Solicitud) and P.Encendido:
                    if 'arduino' in locals():
                        print("Cerrando comunicación")
                        print("Planta:" + P.nombre + " Puerto:"+ P.puerto)
                        print(datetime.now())

                        arduino.close()
                        del arduino
                    P.Encendido=False
                    P.save()
                    Ultimo = datetime.now()

                if (not P.Solicitud) and (not P.Encendido):
                    if 'arduino' in locals():
                        print("Cerrando comunicación")
                        print("Planta:" + P.nombre + " Puerto:"+ P.puerto)
                        print(datetime.now())
                        arduino.close()
                        del arduino
            else:
                if not Archivo.error:
                    if 'arduino' in locals():
                        print("Cerrando comunicación")
                        print(datetime.now())
                        P.Encendido=False
                        P.save()
                        arduino.close()
                        del arduino
                        Ultimo = datetime.now()
                    D[8] = "D:\\LabWebUQ\\media\\" + Archivo.archivo_out.name
                    Respuesta = subprocess.call(D)
                    print(datetime.now())

                    if Respuesta == 0:
                        Archivo.se_ha_subido = True
                    else:
                        Archivo.Datos_error =str(Respuesta)
                        Archivo.error = True
                    Archivo.save()
    
        if msvcrt.kbhit():
            tecla = msvcrt.getch()
            if tecla==b'x' and P.Encendido:
                P.Encendido=False
                P.save()
                arduino.close()
                del arduino
        
        if 'arduino' in locals() and not esta_ocupada(P):
            P.Solicitud = False
            P.save()