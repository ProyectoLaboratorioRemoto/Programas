from django.contrib.auth import authenticate, login, logout
from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import render
from django.urls import reverse
from datetime import datetime
from django.contrib.auth.models import User
from cita.views import encuentra_siguiente_practica
from cita.models import Practica,EmailTrabajo
from labRemoto.models import Planta
from django.http import JsonResponse

# Create your views here.
import requests
from random import randint


claveComunicacion = "a.e23cgw"
clavesec = "a.e23cgw"

# emisor y receptor conocen la clave
def encriptar(proceso,clave):
    proceso = proceso + clave
    enviar = ""
    for i in range(0,len(proceso)):
        enviar=enviar+chr((ord(proceso[i])+ord(clave[i%len(clave)])-64)//11+ord('a'))
        enviar=enviar+chr((ord(proceso[i])+ord(clave[i%len(clave)])-64)%11 +ord('m'))        
    return enviar
    

def desencriptar(proceso,clave):
    enviar = ""
    for i in range(0,len(proceso)-1,2):
        temp = (ord(proceso[i])-ord('a'))*11+ord(proceso[i+1])-ord('m')
        temp = temp+64-ord(clave[(i//2)%len(clave)])
        if temp<32:
            temp=32
        if temp>127:
            temp=127
        enviar = enviar + chr(temp)
    if enviar[-len(clave):] != clave:
        return "",True
    return enviar[:-len(clave)],False

def generaClave(num_caract=8):
    clave = ""
    for i in range(0,num_caract):
        selec = randint(0,3)
        if selec==0:
            clave = clave+chr(randint(0,25)+ord('A'))
        if selec==1:
            clave = clave+chr(randint(0,25)+ord('a'))
        if selec==2:
            clave = clave+chr(randint(0,9)+ord('0'))
        if selec==3:
            clave = clave+chr(randint(0,3)+ord('#'))
    return clave


def index(request,message=None):
    if request.user.is_authenticated:
        return HttpResponseRedirect(reverse('citas:index'))
    texto = request.GET.get('texto','')
    if len(texto)==0:
        return render(request, "registration/login.html", {'error':'Error ingresando (cod 0)'})

    if not 'solicitud' in request.session:
        return render(request, "registration/login.html", {'sig':'Jaiber Verifique'})

    clavesec,fallo = desencriptar(request.session['solicitud'],claveComunicacion)

    if fallo:
        return render(request, "registration/login.html", {'error':'Error ingresando (cod 1)'})
    
    email,fallo = desencriptar(texto,clavesec)
    if fallo:
        return render(request, "registration/login.html", {'error':'Error ingresando (cod 2)'})
    x = User.objects.filter(email=email).last()
    if x is None:
        x = User(username=email,email=email)
    clave = generaClave()
    x.set_password(clave)
    x.save()
    user = authenticate(request,username=email, password=clave)
    if user is None:
        return render(request, "registration/login.html", {'error':'Error ingresando (cod 3)'})
    else:
        login(request,user)
    request.session['solicitud']=encriptar(generaClave(),claveComunicacion)

    # Inicio acceso libre a levitador
    # email,created = EmailTrabajo.objects.get_or_create(email=request.user.email)
    # levitador = Planta.objects.get(nombre='Levitador')
    # practica = Practica.objects.get(planta=levitador)
    # practica.usuario.add(email)
    # Fin acceso libre a levitador

    return HttpResponseRedirect(reverse('labRemoto:index'))
    # enviar = 'correo: '+email+'\nclave: '+clave
    # return render(request, "registration/login.html", {'recordatorio':enviar})

def recupera(request):
    if request.user.is_authenticated:
        return HttpResponseRedirect(reverse('citas:index'))
    request.session['solicitud']=encriptar(generaClave(),claveComunicacion)
    return HttpResponseRedirect('http://www.controluq2.online/LabWebUQ/?solicitud=' + request.session['solicitud'])
    
def recuperab(request):
    if request.user.is_authenticated:
        return HttpResponseRedirect(reverse('citas:index'))
    request.session['solicitud']=encriptar(generaClave(),claveComunicacion)
    return HttpResponseRedirect('http://www.controluq2.online/LabWebUQ/b/?solicitud=' + request.session['solicitud'])
