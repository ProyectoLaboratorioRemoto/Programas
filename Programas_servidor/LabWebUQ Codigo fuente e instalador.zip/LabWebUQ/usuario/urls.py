from django.urls import path
from . import views

app_name = 'usuario' 
urlpatterns = [
    path("", views.index, name="index"),
    path("recupera/", views.recupera, name="recupera"),
    path("recuperab/", views.recuperab, name="recuperab"),

]
