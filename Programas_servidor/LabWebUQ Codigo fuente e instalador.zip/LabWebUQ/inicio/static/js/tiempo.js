/*
Contador regresivo que se copia en el tag con Id 'countdown', 
se deben definir tres variables antes de llamar este archivo:
** variable end con la fecha y hora final buscada:
** variable textoAntes con el mensaje antes de llegar a la hora final
** variable textoDespues con el mensaje después de la hora final
Ejemplo:

var end = new Date('7/21/2020 12:0');
var textoAntes = "Puede usar el laboratiorio Levitador en: ";
var textoDespues = "En este momento puede usar el laboratorio: Levitador"
*/


var _second = 1000;
var _minute = _second * 60;
var _hour = _minute * 60;
var _day = _hour * 24;
var timer;                
function showRemaining() {
    var now = new Date();
    var distance = end - now;
    if (distance < 0) {

        clearInterval(timer);
        document.getElementById('countdown').innerHTML = textoDespues;

        return;
    }
    var days = Math.floor(distance / _day);
    var hours = Math.floor((distance % _day) / _hour);
    var minutes = Math.floor((distance % _hour) / _minute);
    var seconds = Math.floor((distance % _minute) / _second);
    document.getElementById('countdown').innerHTML = textoAntes;
    if (days > 0) document.getElementById('countdown').innerHTML += days + ':';
    if (hours < 10) document.getElementById('countdown').innerHTML += '0';
        document.getElementById('countdown').innerHTML += hours + ':';
    if (minutes < 10) document.getElementById('countdown').innerHTML += '0';
        document.getElementById('countdown').innerHTML += minutes + ':';
    if (seconds < 10) document.getElementById('countdown').innerHTML += '0';       
        document.getElementById('countdown').innerHTML += seconds ;
}

timer = setInterval(showRemaining, 1000);
