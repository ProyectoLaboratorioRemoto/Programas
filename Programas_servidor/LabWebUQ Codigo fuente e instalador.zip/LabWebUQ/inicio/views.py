import os
from django.conf import settings
from django.http import HttpResponse, Http404, HttpResponseRedirect
from django.shortcuts import render
from django.contrib.auth.models import User
from django.urls import reverse

# Create your views here.
def index(request):
    """Direcciona a la página de inicio del proyecto"""
    context = {
        "texto_inicio":"bienvenido a la página"
        }
    if request.user.is_authenticated:
        context['usuario']=request.user.username
    return render(request, 'inicio/index.html', context)

def info(request,sistema='levitador'):
    if sistema=='servo':
        return render(request, 'inicio/servo.html', {})
    if sistema=='robot2d':
        return render(request, 'inicio/robot2d.html', {})
    if sistema=='levitador':
        return render(request, 'inicio/levitador.html', {})
    if sistema=='acercade':
        return render(request, 'inicio/acercade.html', {})

    return HttpResponseRedirect(reverse('inicio:info', kwargs={'sistema':"levitador"}))
    
def download(request, path):
    file_path = os.path.join(settings.MEDIA_ROOT, path)
    if path not in ['Levitador_neumatico_control_proporcional.out',
                    'Control_Prop_servo_TxRx_22nov21.out',
                    'Control_Prop_Articulaciones_TxRx_19mayo21.out',]:
        raise Http404
    if os.path.exists(file_path):
        with open(file_path, 'rb') as fh:
            response = HttpResponse(fh.read(), content_type="application/octet-stream")
            response['Content-Disposition'] = 'inline; filename=' + os.path.basename(file_path)
            return response
    raise Http404