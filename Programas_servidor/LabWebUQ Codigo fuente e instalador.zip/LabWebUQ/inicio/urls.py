from django.urls import path
from . import views
 
# url patterns
app_name = 'inicio'  
urlpatterns = [
    path("", views.index, name="index"),
    path("download/<str:path>",views.download, name="download"),
    path('accounts/profile/', views.index, name="indexprofile"),
    path("info/<str:sistema>",views.info, name="info"),
]
